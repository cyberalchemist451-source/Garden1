'use client';

import { useRef, useEffect, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { useSimulationStore, RobotIntent } from '@/lib/simulationStore';
import { getTerrainHeight } from '@/components/simulation/Terrain';
import { ObjectMemoryManager } from '@/lib/objectMemory';
import { TemporalExperienceManager } from '@/lib/temporalExperience';
import { RobotCognitiveLightCone } from './RobotCognitiveCone';
import { RobotSpeechBubble } from './RobotSpeechBubble';

const METAL_DARK = '#1a1a2e';
const METAL_MID = '#2a2a40';
const ACCENT_ORANGE = '#ff6600';

// Robot's own memory instance
const robotMemory = new ObjectMemoryManager();

// Feature flag to disable temporal system if causing issues
const ENABLE_TEMPORAL = true;

// Robot's temporal experience manager
let temporalManager: TemporalExperienceManager | null = null;
if (ENABLE_TEMPORAL) {
    temporalManager = new TemporalExperienceManager({
        baseCompressionRatio: 1.0,
        tokenBudgetPerSecond: 100,
        memoryConsolidationInterval: 5.0,
        maxMemoryEntries: 50,
    });
}

export default function AtlasRobot() {
    const groupRef = useRef<THREE.Group>(null);
    const leftArmRef = useRef<THREE.Group>(null);
    const rightArmRef = useRef<THREE.Group>(null);
    const leftLegRef = useRef<THREE.Group>(null);
    const rightLegRef = useRef<THREE.Group>(null);

    const keys = useRef<Set<string>>(new Set());
    const position = useRef(new THREE.Vector3(15, 0, 15));
    const velocity = useRef(new THREE.Vector3());
    const intentStartTime = useRef<number>(0);
    const processingVision = useRef(false);

    const environment = useSimulationStore(s => s.environment);
    const colliders = useSimulationStore(s => s.colliders);
    const currentIntent = useSimulationStore(s => s.robot.currentIntent);
    const isSitting = useSimulationStore(s => s.robot.isSitting);
    const sittingPosition = useSimulationStore(s => s.robot.sittingPosition);

    const { scene, gl } = useThree();
    const {
        setRobotSitting,
        clearRobotIntent,
        completeIntent,
        updateNearbyObjects,
        addSensoryInput,
        setRobotTemporalMetrics,
        triggerInteraction,
        addChatMessage
    } = useSimulationStore();

    const compressionRatio = useSimulationStore(s => s.robot.temporalMetrics?.compressionRatio ?? 1);
    const simTime = useRef(0);
    const metricsUpdateCounter = useRef(0);
    const scanCounter = useRef(0);
    const prevNearbyRef = useRef<string[]>([]);

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (useSimulationStore.getState().isChatOpen) return;
            const key = e.key.toLowerCase();
            if (['i', 'j', 'k', 'l', 'u', 'o', 'y', 'h', 'n', 'm'].includes(key)) keys.current.add(key);
        };
        const handleKeyUp = (e: KeyboardEvent) => {
            const key = e.key.toLowerCase();
            if (['i', 'j', 'k', 'l', 'u', 'o', 'y', 'h', 'n', 'm'].includes(key)) keys.current.delete(key);
        };
        window.addEventListener('keydown', handleKeyDown);
        window.addEventListener('keyup', handleKeyUp);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
            window.removeEventListener('keyup', handleKeyUp);
        };
    }, []);

    const vy = useRef(0);
    const isGrounded = useRef(true);

    const captureVisualInput = () => {
        try {
            return gl.domElement.toDataURL('image/jpeg', 0.5);
        } catch (e) {
            console.error("Failed to capture visual input", e);
            return null;
        }
    };

    useFrame((state, delta) => {
        if (!groupRef.current) return;

        const safeDelta = Math.min(delta, 0.1);
        const currentCompression = useSimulationStore.getState().robot.temporalMetrics?.compressionRatio ?? 1;
        const dt = safeDelta * currentCompression;
        simTime.current += dt;

        const GRAVITY = 20;
        const JUMP_FORCE = 8;
        const speed = 4;
        const turnSpeed = 2.5;

        // 1. Sitting Check & Stand Up Logic
        if (isSitting && sittingPosition) {
            // Check if robot needs to stand up to fulfill an intent
            if (currentIntent && !currentIntent.completed) {
                const needsMobility = ['move', 'turn', 'interact'].includes(currentIntent.type) && currentIntent.action !== 'sit';
                if (needsMobility) {
                    setRobotSitting(false);
                }
            }

            const sitPos = sittingPosition;
            groupRef.current.position.set(sitPos.x, sitPos.y + 0.5, sitPos.z);
            position.current.copy(groupRef.current.position);

            const sittingRotation = useSimulationStore.getState().robot.sittingRotation;
            if (sittingRotation !== undefined) {
                groupRef.current.rotation.y = sittingRotation;
            }

            vy.current = 0;
            isGrounded.current = true;
            return;
        }

        // 2. Intent Execution Pre-calc
        let dx = 0;
        let dz = 0;
        let shouldTurn = false;
        let turnDirection = 0;
        let jump = false;

        // Intent Queue Pulse
        if (currentIntent && !currentIntent.completed && intentStartTime.current === 0) {
            intentStartTime.current = Date.now();
        }
        if (!currentIntent && useSimulationStore.getState().robot.intentQueue.length > 0) {
            useSimulationStore.getState().processNextIntent();
        }

        // Processing Intents
        if (currentIntent && !currentIntent.completed) {
            const elapsed = (Date.now() - intentStartTime.current) / 1000;

            switch (currentIntent.type) {
                case 'move':
                    if (currentIntent.action === 'forward') dz = -1;
                    else if (currentIntent.action === 'backward') dz = 1;
                    else if (currentIntent.action === 'strafe-left') dx = -1;
                    else if (currentIntent.action === 'strafe-right') dx = 1;
                    else if (currentIntent.action === 'jump') { if (elapsed < 0.1 && isGrounded.current) jump = true; }

                    if (elapsed > (currentIntent.duration || 2)) {
                        clearRobotIntent();
                        intentStartTime.current = 0;
                    }
                    break;

                case 'turn':
                    shouldTurn = true;
                    if (currentIntent.action === 'face-user') {
                        const userState = useSimulationStore.getState().user;
                        if (userState.position) {
                            const angle = Math.atan2(userState.position.x - position.current.x, userState.position.z - position.current.z);
                            let angDiff = angle - groupRef.current.rotation.y;
                            while (angDiff > Math.PI) angDiff -= 2 * Math.PI;
                            while (angDiff < -Math.PI) angDiff += 2 * Math.PI;
                            turnDirection = angDiff > 0 ? 1 : -1;
                            if (Math.abs(angDiff) < 0.1) {
                                clearRobotIntent();
                                intentStartTime.current = 0;
                            }
                        } else clearRobotIntent();
                    } else {
                        turnDirection = currentIntent.action === 'left' ? 1 : -1;
                        if (elapsed > 0.5) { clearRobotIntent(); intentStartTime.current = 0; }
                    }
                    break;

                case 'stop':
                    clearRobotIntent();
                    intentStartTime.current = 0;
                    break;

                case 'interact':
                    if (currentIntent.action === 'sit') {
                        const targets = colliders.filter(c => c.type === 'chair' || (c.interactable && c.metadata?.action === 'sit'));
                        if (targets.length > 0) {
                            const userState = useSimulationStore.getState().user;
                            let target = targets[0];
                            if (userState.isSitting && userState.sittingPosition && targets.length > 1) {
                                const userPosV3 = new THREE.Vector3(userState.sittingPosition.x, userState.sittingPosition.y, userState.sittingPosition.z);
                                const occupied = targets.find(c => new THREE.Vector3(c.position.x, c.position.y, c.position.z).distanceTo(userPosV3) < 1.0);
                                if (occupied) target = targets.find(c => c.id !== occupied.id) || target;
                            }
                            setRobotSitting(true, { x: target.position.x, y: target.position.y - 0.5, z: target.position.z });
                            clearRobotIntent();
                            intentStartTime.current = 0;
                        } else { clearRobotIntent(); intentStartTime.current = 0; }
                    } else if (currentIntent.action === 'stand') {
                        setRobotSitting(false);
                        clearRobotIntent();
                        intentStartTime.current = 0;
                    } else if (currentIntent.action === 'follow') {
                        const userState = useSimulationStore.getState().user;
                        if (userState.position) {
                            const ux = userState.position.x - position.current.x;
                            const uz = userState.position.z - position.current.z;
                            const dist = Math.sqrt(ux * ux + uz * uz);
                            if (dist < 2.0) {
                                velocity.current.set(0, 0, 0);
                                groupRef.current.rotation.y = Math.atan2(ux, uz);
                                completeIntent();
                                intentStartTime.current = 0;
                            } else {
                                const moveDir = new THREE.Vector3(ux, 0, uz).normalize();
                                velocity.current.copy(moveDir).multiplyScalar(4.0 * safeDelta);
                                position.current.add(velocity.current);
                                const angle = Math.atan2(ux, uz);
                                let angDiff = angle - groupRef.current.rotation.y;
                                while (angDiff > Math.PI) angDiff -= 2 * Math.PI;
                                while (angDiff < -Math.PI) angDiff += 2 * Math.PI;
                                groupRef.current.rotation.y += angDiff * 5.0 * safeDelta;
                            }
                            if (elapsed > 15) { clearRobotIntent(); intentStartTime.current = 0; }
                        } else clearRobotIntent();
                    } else if (currentIntent.action === 'open' || currentIntent.action === 'close') {
                        const targets = colliders.filter(c => c.interactable && (c.type === 'door' || c.metadata?.action === currentIntent.action));
                        if (targets.length > 0) {
                            const target = targets.reduce((p, c) => new THREE.Vector3(p.position.x, p.position.y, p.position.z).distanceTo(position.current) < new THREE.Vector3(c.position.x, c.position.y, c.position.z).distanceTo(position.current) ? p : c);
                            const dist = new THREE.Vector3(target.position.x, target.position.y, target.position.z).distanceTo(position.current);
                            if (dist < 3.0) {
                                triggerInteraction(target.id, currentIntent.action);
                                groupRef.current.rotation.y = Math.atan2(target.position.x - position.current.x, target.position.z - position.current.z);
                                clearRobotIntent();
                                intentStartTime.current = 0;
                            } else {
                                const moveDir = new THREE.Vector3(target.position.x - position.current.x, 0, target.position.z - position.current.z).normalize();
                                velocity.current.copy(moveDir).multiplyScalar(4.0 * safeDelta);
                                position.current.add(velocity.current);
                                groupRef.current.rotation.y = Math.atan2(target.position.x - position.current.x, target.position.z - position.current.z);
                                if (elapsed > 10) { clearRobotIntent(); intentStartTime.current = 0; }
                            }
                        } else { clearRobotIntent(); intentStartTime.current = 0; }
                    } else { clearRobotIntent(); intentStartTime.current = 0; }
                    break;

                case 'query':
                    if (currentIntent.action === 'vision' && !processingVision.current) {
                        processingVision.current = true;
                        const useMultimodal = currentIntent.parameters?.fidelity === 'high' || currentIntent.parameters?.useVision === true;
                        const image = useMultimodal ? captureVisualInput() : null;
                        const robotState = useSimulationStore.getState().robot;
                        const userState = useSimulationStore.getState().user;
                        const known = Object.values(robotState.knownObjects || {}).map(k => `${k.type} (last seen ${(Date.now() - k.lastSeen) / 1000}s ago)`).join(', ') || 'nothing yet';

                        fetch('/api/robot', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                type: 'analysis',
                                message: `describe surroundings. Known memory: ${known}`,
                                robotState: { ...robotState },
                                userState,
                                image
                            })
                        })
                            .then(res => res.json())
                            .then(data => {
                                const text = data.response || 'I perceive... nothing.';
                                const duration = Math.max(4000, text.length * 80);
                                const uState = useSimulationStore.getState().user;
                                const distToUser = uState.position
                                    ? new THREE.Vector3(uState.position.x, uState.position.y, uState.position.z).distanceTo(position.current)
                                    : 999;

                                if (distToUser > 12.0) {
                                    useSimulationStore.getState().setRobotSpeech('You are too far away.', 3000);
                                } else {
                                    if (groupRef.current && uState.position) {
                                        groupRef.current.rotation.y = Math.atan2(uState.position.x - position.current.x, uState.position.z - position.current.z);
                                    }
                                    useSimulationStore.getState().setRobotSpeech(text, duration);
                                    addChatMessage({ role: 'robot', text, nodeName: 'ATLAS', nodeAvatar: '◇', isRobotCommand: true });
                                }
                                setTimeout(() => { completeIntent(); intentStartTime.current = 0; processingVision.current = false; }, duration);
                            })
                            .catch(err => {
                                const errMsg = err instanceof Error ? err.message : String(err);
                                console.error('[Atlas Vision] Failed:', errMsg);
                                addChatMessage({ role: 'robot', text: `Vision error: ${errMsg}`, nodeName: 'ATLAS', nodeAvatar: '◇', isRobotCommand: true });
                                completeIntent();
                                intentStartTime.current = 0;
                                processingVision.current = false;
                            });
                    }
                    break;

                case 'chat':
                    const userState = useSimulationStore.getState().user;
                    groupRef.current.rotation.y = Math.atan2(userState.position.x - position.current.x, userState.position.z - position.current.z);
                    clearRobotIntent();
                    intentStartTime.current = 0;
                    break;

                default:
                    clearRobotIntent();
                    intentStartTime.current = 0;
                    break;
            }
        } else {
            // Manual Controls
            if (keys.current.has('i')) dz -= 1;
            if (keys.current.has('k')) dz += 1;
            if (keys.current.has('u')) dx -= 1;
            if (keys.current.has('o')) dx += 1;
            if (keys.current.has('j')) { shouldTurn = true; turnDirection = 1; }
            if (keys.current.has('l')) { shouldTurn = true; turnDirection = -1; }
        }

        if (shouldTurn) groupRef.current.rotation.y += turnSpeed * dt * turnDirection;

        // 3. Physics & Collisions
        if (jump && isGrounded.current) { vy.current = JUMP_FORCE; isGrounded.current = false; }
        vy.current -= GRAVITY * dt;

        let moveX = dx * speed * dt;
        let moveZ = dz * speed * dt;
        if (dx !== 0 && dz !== 0) { moveX *= 0.707; moveZ *= 0.707; }

        const nextX = position.current.x + moveX;
        const nextZ = position.current.z + moveZ;
        const nextY = position.current.y + vy.current * dt;

        const terrainY = getTerrainHeight(nextX, nextZ, environment.terrain.seed, environment.terrain.heightScale);
        let groundHeight = terrainY;
        let blocked = false;

        for (const collider of colliders) {
            const hX = collider.size.x / 2;
            const hZ = collider.size.z / 2;
            const hY = collider.size.y / 2;
            const isOpen = collider.type === 'door' && collider.metadata?.state === 'open';

            if (!isOpen && Math.abs(nextX - collider.position.x) < hX + 0.5 && Math.abs(nextZ - collider.position.z) < hZ + 0.5) {
                const top = collider.position.y + hY;
                const diff = top - position.current.y;
                if (diff > -0.1 && diff < 0.6 && (collider.climbable || collider.type === 'log')) {
                    // Step up
                } else if (position.current.y < top - 0.2) {
                    blocked = true;
                }
            }
            if (Math.abs(nextX - collider.position.x) < hX && Math.abs(nextZ - collider.position.z) < hZ) {
                if (position.current.y >= collider.position.y + hY - 0.5 && (collider.climbable || collider.type === 'log')) {
                    groundHeight = Math.max(groundHeight, collider.position.y + hY);
                }
            }
        }

        if (nextY <= groundHeight) { position.current.y = groundHeight; vy.current = 0; isGrounded.current = true; }
        else { position.current.y = nextY; isGrounded.current = false; }
        if (!blocked) { position.current.x = nextX; position.current.z = nextZ; }
        groupRef.current.position.copy(position.current);

        // 4. Animation
        const isMoving = dx !== 0 || dz !== 0;
        const t = simTime.current;
        if (isMoving) {
            if (leftLegRef.current) leftLegRef.current.rotation.x = Math.sin(t * 6) * 0.4;
            if (rightLegRef.current) rightLegRef.current.rotation.x = Math.sin(t * 6 + Math.PI) * 0.4;
            if (leftArmRef.current) leftArmRef.current.rotation.x = Math.sin(t * 6 + Math.PI) * 0.25;
            if (rightArmRef.current) rightArmRef.current.rotation.x = Math.sin(t * 6) * 0.25;
        } else {
            if (leftLegRef.current) leftLegRef.current.rotation.x = 0;
            if (rightLegRef.current) rightLegRef.current.rotation.x = 0;
            if (leftArmRef.current) { leftArmRef.current.rotation.x = 0; leftArmRef.current.rotation.z = 0.1; }
            if (rightArmRef.current) { rightArmRef.current.rotation.x = 0; rightArmRef.current.rotation.z = -0.1; }
        }

        // 5. Optimized Sensory Scanning
        scanCounter.current++;
        if (scanCounter.current % 30 === 0) {
            const visionRange = 60;
            const visionRangeSq = visionRange * visionRange;
            const visionAngle = 60;
            const nearby: string[] = [];

            for (const collider of colliders) {
                const cx = collider.position.x - position.current.x;
                const cz = collider.position.z - position.current.z;
                const dSq = cx * cx + cz * cz;
                if (dSq > visionRangeSq) continue;

                const local = new THREE.Vector3(cx, 0, cz).applyAxisAngle(new THREE.Vector3(0, 1, 0), -groupRef.current.rotation.y);
                const angle = Math.abs(Math.atan2(local.x, local.z));
                if (angle < (visionAngle * Math.PI) / 360) {
                    const isUser = collider.id === 'user-avatar' || collider.id.includes('user');
                    const dist = Math.sqrt(dSq);
                    const label = isUser ? `👤 Corto (${dist.toFixed(1)}m)` : `${collider.metadata?.displayName || collider.type} (${dist.toFixed(1)}m)`;
                    nearby.push(label);

                    // Memory & Permanence
                    const robotState = useSimulationStore.getState().robot;
                    if (!robotState.knownObjects[collider.id] || Date.now() - robotState.knownObjects[collider.id].lastSeen > 1000) {
                        robotState.registerObject(collider.id, collider.type, collider.position);
                        if (!robotState.knownObjects[collider.id]) console.log(`[Atlas] Noticed ${collider.type}`);
                    }
                    addSensoryInput({ type: 'vision', sourceId: collider.id, sourceType: collider.type, position: collider.position, intensity: 1.0 - (dist / visionRange), timestamp: Date.now() });
                }
            }

            // Explicit User Check (if not in colliders)
            const uState = useSimulationStore.getState().user;
            if (uState.position && !nearby.some(n => n.includes('Corto'))) {
                const ux = uState.position.x - position.current.x;
                const uz = uState.position.z - position.current.z;
                const udSq = ux * ux + uz * uz;
                if (udSq < visionRangeSq) {
                    const uLocal = new THREE.Vector3(ux, 0, uz).applyAxisAngle(new THREE.Vector3(0, 1, 0), -groupRef.current.rotation.y);
                    if (Math.abs(Math.atan2(uLocal.x, uLocal.z)) < (visionAngle * Math.PI) / 360) {
                        nearby.push(`👤 Corto (${Math.sqrt(udSq).toFixed(1)}m)`);
                    }
                }
            }

            const currentNearbyStr = [...new Set(nearby)].sort().join(',');
            const prevNearbyStr = prevNearbyRef.current.sort().join(',');
            if (currentNearbyStr !== prevNearbyStr) {
                updateNearbyObjects(nearby);
                prevNearbyRef.current = nearby;
            }
        }

        // 6. Temporal Logic
        if (temporalManager) {
            temporalManager.setCompressionRatio(compressionRatio);
            temporalManager.tick(safeDelta, robotMemory);
            metricsUpdateCounter.current++;
            if (metricsUpdateCounter.current >= 30) {
                metricsUpdateCounter.current = 0;
                setRobotTemporalMetrics(temporalManager.getMetrics());
            }
        }
    });

    return (
        <group ref={groupRef} name="atlasRobot">
            <mesh position={[0, 1.8, 0]} castShadow>
                <boxGeometry args={[0.3, 0.3, 0.3]} />
                <meshStandardMaterial color={METAL_MID} roughness={0.3} metalness={0.8} />
            </mesh>
            <mesh position={[0, 1.8, 0.16]}>
                <planeGeometry args={[0.2, 0.06]} />
                <meshStandardMaterial color={ACCENT_ORANGE} emissive={ACCENT_ORANGE} emissiveIntensity={currentIntent ? 1.2 : 0.8} />
            </mesh>
            <mesh position={[0, 1.1, 0]} castShadow>
                <boxGeometry args={[0.5, 0.8, 0.3]} />
                <meshStandardMaterial color={METAL_DARK} roughness={0.4} metalness={0.7} />
            </mesh>
            <mesh position={[0, 0.6, 0]} castShadow>
                <boxGeometry args={[0.4, 0.3, 0.25]} />
                <meshStandardMaterial color={METAL_MID} roughness={0.5} metalness={0.6} />
            </mesh>
            <group ref={leftArmRef} position={[-0.35, 1.2, 0]}>
                <mesh castShadow><boxGeometry args={[0.12, 0.6, 0.12]} /><meshStandardMaterial color={METAL_DARK} /></mesh>
            </group>
            <group ref={rightArmRef} position={[0.35, 1.2, 0]}>
                <mesh castShadow><boxGeometry args={[0.12, 0.6, 0.12]} /><meshStandardMaterial color={METAL_DARK} /></mesh>
            </group>
            <group ref={leftLegRef} position={[-0.15, 0.35, 0]}>
                <mesh castShadow><boxGeometry args={[0.14, 0.7, 0.14]} /><meshStandardMaterial color={METAL_MID} /></mesh>
            </group>
            <group ref={rightLegRef} position={[0.15, 0.35, 0]}>
                <mesh castShadow><boxGeometry args={[0.14, 0.7, 0.14]} /><meshStandardMaterial color={METAL_MID} /></mesh>
            </group>
            <pointLight position={[0, 1.8, 0.3]} color={ACCENT_ORANGE} intensity={currentIntent ? 0.6 : 0.3} distance={3} />
            <RobotCognitiveLightCone />
            <RobotSpeechBubble />
        </group>
    );
}

export { robotMemory };
